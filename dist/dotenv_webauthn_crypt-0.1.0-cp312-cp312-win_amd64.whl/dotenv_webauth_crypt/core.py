import os
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from . import _native

# Data location
DATA_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "dotenv-webauth")

def get_vault_key(env_path: str, master_key: bytes) -> bytes:
    # HKDF-SHA256 Derivation
    vault_id = hashlib.sha256(os.path.abspath(env_path).encode()).digest()
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=vault_id,
        info=b"dotenv-webauth-v1",
        backend=default_backend()
    )
    return hkdf.derive(master_key)

def decrypt_value(ciphertext_b64: str, vault_key: bytes) -> str:
    data = base64.b64decode(ciphertext_b64)
    nonce = data[0:12]
    ciphertext = data[12:]
    
    aesgcm = AESGCM(vault_key)
    decrypted = aesgcm.decrypt(nonce, ciphertext, None)
    return decrypted.decode('utf-8')

def load_dotenv(dotenv_path: str = ".env"):
    if not os.path.exists(dotenv_path):
        return

    # Trigger WebAuthn to get master key
    challenge = b"dotenv-webauth-fixed-challenge"
    signature = bytes(_native.get_signature(list(challenge)))
    master_key = hashlib.sha256(signature).digest()

    vault_key = get_vault_key(dotenv_path, master_key)
    
    with open(dotenv_path, "r") as f:
        for line in f:
            if "=" in line:
                key, value = line.strip().split("=", 1)
                if value.startswith("ENC:"):
                    # Decrypting
                    try:
                        decrypted = decrypt_value(value[4:], vault_key)
                        os.environ[key] = decrypted
                    except Exception as e:
                        print(f"Decryption failed for {key}: {e}")
                else:
                    os.environ[key] = value
