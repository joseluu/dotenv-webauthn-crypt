import sys
import argparse
from .core import load_dotenv

def main():
    parser = argparse.ArgumentParser(description="dotenv-webauth-crypt CLI")
    parser.add_argument("command", choices=["encrypt", "decrypt", "init", "rekey"])
    parser.add_argument("env_path", nargs="?", default=".env")
    
    args = parser.parse_args()
    
    if args.command == "decrypt":
        load_dotenv(args.env_path)
        print("Variables decrypted and loaded into environment.")
    else:
        print(f"Command '{args.command}' not yet implemented.")

if __name__ == "__main__":
    main()
